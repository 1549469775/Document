CardTool.prototype.deviceMagic = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        if (array[i].magic) {
            painum.push(array[i]);
            array.splice(i, 1);
            i--;
        }
    }
    return painum;
}

//根据权重排序
CardTool.prototype.weightSort = function (array) {
    array.sort(function (a, b) {
        return a.weight - b.weight;
    });
};

//分离出牌的物理大小
CardTool.prototype.deviceId = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        painum[i] = array[i].id;
    }
    return painum;
}

//分离出牌的物理大小
CardTool.prototype.deviceOrigin = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        painum[i] = array[i].origin;
    }
    return painum;
}

//分离出牌的物理大小
CardTool.prototype.deviceNum = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        painum[i] = array[i].num;
    }
    return painum;
}
//分离出牌的物理权重
CardTool.prototype.deviceWeight = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        painum[i] = array[i].weight;
    }
    return painum;
}
//分离出牌的物理权重
CardTool.prototype.deviceColor = function (array) {
    var painum = [];
    for (let i = 0; i < array.length; i++) {
        painum[i] = array[i].color;
    }
    return painum;
}

CardTool.prototype.maxNumber = function (array) {
    var result = [];
    result = array.filter((v, i, s) => {
        return array[0].num == v.num;
    });
    return result;
};
//获取最多的牌数量
CardTool.prototype.allNumber = function (array) {
    var card = [];
    var number = []
    var num = {};
    var result = [];
    //字典存储
    array.forEach((v, i, s) => {
        if (num[v]) {
            num[v]++;
        } else {
            num[v] = 1;
        }
    });

    card = array.filter((v, i, s) => {
        return array.indexOf(v) == i;
    });
    card.forEach((v, i) => {
        number[i] = num[v];
    })
    var len = card.length;
    for (let i = 0; i < len; i++) {
        var obj = {
            val: card[i],
            num: number[i]
        }
        result[i] = obj;
    }
    result.sort(function (a, b) {
        return b.num - a.num;
    });
    return result;
};

//权重分组
CardTool.prototype.groupsWeight = function (array) {
    var weights = {};
    var result = [];
    //遍历权重
    array.forEach(function (value, index, self) {
        if (weights[value.weight] == undefined) {
            weights[value.weight] = [];
        }
        if (weights[value.weight]) {
            weights[value.weight].push(value);
        }
    })
    return weights;
}

CardTool.prototype.checkSHUN = function (array) {
    var result = 1;
    for (let i = 1; i < array.length; i++) {
        if (array[i] != array[i - 1] + 1) {
            result = 0;
            break;
        }
    }
    return result;
}

CardTool.prototype.checkNUM = function (num,hands) {
   var number=0;
   for (let i = 0; i < hands.length; i++) {
       if (hands[i]==num) {
           number++;
       }
   }
    return number;
}

function CardTool() {

}