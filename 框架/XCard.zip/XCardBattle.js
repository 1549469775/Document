var Battle = (function () {
    var output = {};
    output.check = function (Arr) {
        Arr = new CardType(Arr);
        var arrType = Arr.type;
        if (arrType !== 'error') {
            return arrType.type;
        }
        return false;
    };
    output.tong = function (prevArr, nextArr) {
        prevArr = new CardType(prevArr);
        nextArr = new CardType(nextArr);
        var prevType = prevArr.type;
        var nextType = nextArr.type;
        if (prevType && nextType && prevType !== 'error' && nextType !== 'error') {
            if (prevType.cardWeight == nextType.cardWeight) {
                return true;
            }
        }
        return false;
    };
    output.beat = function (prevArr, nextArr) {
        // console.log=function(...aa){}
        prevArr = new CardType(prevArr);
        nextArr = new CardType(nextArr);
        var prevType = prevArr.type;
        var nextType = nextArr.type;
        if (prevType && nextType && prevType !== 'error' && nextType !== 'error') {
            if (prevType.cardWeight == nextType.cardWeight) {
                if (prevType.type == nextType.type) {
                    if (prevType.cardNum.length == nextType.cardNum.length) {
                        if (prevType.weight > nextType.weight) {
                            return true;
                        }
                    }
                }
            } else if (prevType.cardWeight > nextType.cardWeight) {
                return true;
            }
        }
        return false;
    };
    output.gdybeat = function (prevArr1, nextArr2,change) {
        // console.log=function(...aa){}
        
        if (change) {
            //右边大于左边,左边确定
            nextArr = new CardType(prevArr1);
            var nextType = nextArr.type;
            if (nextType.type !== 'error') {
                prevArr = new CardType(nextArr2,nextType.weight+1,nextType.type);
                var prevType = prevArr.type;
            }
            // nextArr= new CardType(nextArr2);
            // var nextType = nextArr.type;
            // if (nextType.type !== 'error') {
            //     prevArr = new CardType(prevArr1,nextType.weight+1,nextType.type);
            //     var prevType = prevArr.type;
            // }
        }else{
            //左边大于右边,左边确定
            prevArr = new CardType(prevArr1);
            var prevType = prevArr.type;
            if (prevType.type !== 'error') {
                nextArr = new CardType(nextArr2,prevType.weight-1,prevType.type);
                var nextType = nextArr.type;
            }
            // nextArr = new CardType(nextArr2);
            // var nextType = nextArr.type;
        }
        if (prevType && nextType && prevType !== 'error' && nextType !== 'error') {
            if (prevType.cardWeight == nextType.cardWeight) {
                if (prevType.type == nextType.type) {
                    if (prevType.cardNum.length == nextType.cardNum.length) {
                        if (prevType.weight > nextType.weight && prevType.weight == 13) {
                            return true;
                        }
                        if (prevType.weight > nextType.weight && (prevType.weight - nextType.weight) == 1) {
                            return true;
                        }
                    }
                }
            } else if (prevType.cardWeight > nextType.cardWeight) {
                return true;
            }
        }
        return false;
    };
    output.gdytip = function (cards, hands) {
        var result=new CardHelp(cards,hands);
        return result.beatYou;
    };
    return output
})();