

  CardType.prototype.use=function(name,object){
    CardType.prototype['$'+name]=object;
  }

  CardType.prototype.build=function(object){
    for (const key in object) {
      if (object.hasOwnProperty(key)) {
        const element = object[key];
        CardType.prototype[key]=element;
      }
    }
  }


  //牌型构造
  function CardType(hand,offsetMagic,magicType) {
    let cards=[]; 
    this.build(CardTool.prototype);
    try {
      for (let i = 0; i < hand.length; i++) {
        // hand[i]=this.convertIn(hand[i]);
        var element = hand[i];
        cards[i]=new CardInfo(element,true);
      }
    } catch (e) {
      debugger
    }
    this.offsetMagic=offsetMagic||0;
    this.magicType=magicType||0;
    this.cards=[].concat(cards);
    this.weightSort(this.cards);//权重排序
    this.device={
        weight:this.deviceWeight(this.cards),
        color:this.deviceColor(this.cards),
        number:this.deviceNum(this.cards),
        id:this.deviceId(this.cards),
        origin:this.deviceOrigin(this.cards),
    }
   
    this.count={};
    this.count.allNum=this.allNumber(this.device.weight),//牌数
    this.count.maxNum=this.maxNumber(this.count.allNum),//牌数
    this.check();
    //dan,shun%d,dui,duishun%d,san,sanshun%d,zha

  }
  
  CardType.prototype.createType=function(type,typetimes,cardWeight,weight,cardNum,cardColor,cardId,cardWe){
    return {
      type:type,
      typetimes:typetimes,
      cardWeight:cardWeight,
      weight:weight,
      cardNum:cardNum,
      cardColor:cardColor,
      cardId:cardId,
      cardWe:cardWe,
    }
  }
  
  //检测牌型
  CardType.prototype.checkTong=function(cards){
    cards=[].concat(cards);
    magic_cards=[].concat(this.magicCard);
    var cardsWE=this.deviceWeight(cards);
    // var cardsCO=this.deviceColor(cards);
    // var cardsNU=this.deviceNum(cards);
    // var cardsID=this.deviceId(cards);
    // var cardsOrigin=this.deviceOrigin(cards);
    var allNum=this.allNumber(cardsWE);//牌数
    var maxNum=this.maxNumber(allNum);//多数;
    
    var result;
    if (cards.length==0) {
      return;
    }
    var number=allNum[0].num;
    switch (number) {
      case 1:
        if (allNum.length>=3
          &&allNum.length==maxNum.length
          &&this.checkSHUN(cardsWE)
          && allNum[ allNum.length-1].val<13) {
          // console.log("顺子", cardsWE);
          result=this.createType(
            "shun",allNum.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight
            );
        }else if ( allNum.length==1&& allNum.length== maxNum.length) {
          // console.log("单", cardsWE);
          result=this.createType("dan",1,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
        }
        break;
      case 2:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==2) {
            // console.log("对", cardsWE);
            result=this.createType("dui",1,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        if ( allNum.length>=2
          && allNum[ allNum.length-1].num==2
          && allNum.length== maxNum.length) {
            var card= cardsWE.filter((v,i,s)=>{
              return  cardsWE.indexOf(v)==i;
            });
            if (this.checkSHUN(card)&&card[card.length-1]<13) {
              // console.log("对顺", cardsWE);
              result=this.createType("duishun",card.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
            }
        }
        break;
      case 3:
        if ( allNum.length>1
          && allNum[ allNum.length-1].num==3) {
            var card= cardsWE.filter((v,i,s)=>{
              return  cardsWE.indexOf(v)==i;
            });
            if (this.checkSHUN(card)&&card[card.length-1]<13) {
              // console.log("三顺",cardsWE);
              result=this.createType("sanshun",card.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
            }
        }else if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==3) {
            // console.log("三张", cardsWE);
            result=this.createType("zha",1,2,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
      case 4:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==4) {
            // console.log("炸弹", cardsWE);
            result=this.createType("zha",1,3,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
      case 5:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==5) {
            // console.log("炸弹", cardsWE);
            result=this.createType("zha",1,4,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
      case 6:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==6) {
            // console.log("炸弹", cardsWE);
            result=this.createType("zha",1,5,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
    }
    if (result) {
      return result;
    }
  };
  
  CardType.prototype.checkDai=function(cards){
    //判断3+1,3+(2),3+3+(4),3+3+3+(6)
    //判断4+1,4+(2)
    cards=[].concat(cards);
    magic_cards=[].concat(this.magicCard);
    var cardsWE=this.deviceWeight(cards);
    // var cardsCO=this.deviceColor(cards);
    // var cardsNU=this.deviceNum(cards);
    // var cardsID=this.deviceId(cards);
    // var cardsOrigin=this.deviceOrigin(cards);
    var allNum=this.allNumber(cardsWE);//牌数
    // var maxNum=this.maxNumber(allNum);//多数;
    var result;
    if (result) {
      return result;
    }
  }
  
  CardType.prototype.checkGod=function(cards){
    cards=[].concat(cards);
    magic_cards=[].concat(this.magicCard);
    var cardsWE=this.deviceWeight(cards);
    // var cardsCO=this.deviceColor(cards);
    // var cardsNU=this.deviceNum(cards);
    // var cardsID=this.deviceId(cards);
    // var cardsOrigin=this.deviceOrigin(cards);
    var allNum=this.allNumber(cardsWE);//牌数
    // var maxNum=this.maxNumber(allNum);//多数;
    var result;
    if (magic_cards.length==2&&cards.length==0) {
      result=this.createType("god",100,cardsWE[0],cardsWE);
    }
    if (result) {
      return result;
    }
  }
  
  
  CardType.prototype.checkMagic=function(){
    var magicType;
    var test_cards=[11,12,13,14,15,16,17,18,19,110,111,112,113];
    var magicLen=this.magicCard.length;//癞子长度
    var cardsLen=this.cards.length;//癞子长度
    if (magicLen==1&&cardsLen!=0) {
      var maybe=[];
      for (let i = 0; i < test_cards.length; i++) {
        var cards=[].concat(this.cards);
        cards.push(new CardInfo(test_cards[i],false));
        var type=this.checkAll(cards);
        if (type&&type!=='error') {
            maybe.push(type);
          }
      }
      maybe.sort(function(a,b){
        return a.cardWeight-b.cardWeight;
      });
      var index=maybe.length-1;
      //3,3,4,4,5,5   5,5,6,6,101,102-->5,5,6,6,7,7-->4,4,5,5,6,6
      if (this.offsetMagic!==0) {
        // debugger
        for (let i = 0; i < maybe.length; i++) {
          if (this.offsetMagic==maybe[i].weight&&this.magicType==maybe[i].type) {
            index=i;
            break
          }
        }
      }
      magicType=maybe[index];
    }
    if (magicLen==2&&cardsLen!=0) {
      var maybe=[];
      magic:{
        for (let i = 0; i < test_cards.length; i++) {
          var cards=[].concat(this.cards);
          cards.push(new CardInfo(test_cards[i],false));
          for (let j = 0; j < test_cards.length; j++) {
            var ccc=[].concat(cards);
            ccc.push(new CardInfo(test_cards[j],false));
            var type=this.checkAll(ccc);
            if (type&&type!=='error'&&type.type) {
                maybe.push(type);
              }
          }
        }
      }
      maybe.sort(function(a,b){
        return a.cardWeight-b.cardWeight;
      });
      var index=maybe.length-1;
      //3,3,4,4,5,5   5,5,6,6,101,102-->5,5,6,6,7,7-->4,4,5,5,6,6
      if (this.offsetMagic!==0) {
        // debugger
        for (let i = 0; i < maybe.length; i++) {
          if (this.offsetMagic==maybe[i].weight&&this.magicType==maybe[i].type) {
            index=i;
            break
          }
        }
      }
      magicType=maybe[index];
    }
    return magicType;
  }
  
  CardType.prototype.checkAll=function(cards){
    this.weightSort(cards);
    var type=this.checkTong(cards);
    (!type)&&(type=this.checkGod(cards));
    return type=type||'error';
  }
  
  CardType.prototype.check=function(){
    this.magicCard=this.deviceMagic(this.cards);//分离癞子
    var type=this.checkAll(this.cards);//判断牌型
    var magicType=this.checkMagic();//检测癞子能组的最大类型
    this.type=type||'error';
    // this.magicType=magicType||'error';
    (magicType)&&(this.type=magicType);//癞子类型覆盖
    this.type.__proto__=null;
  }
