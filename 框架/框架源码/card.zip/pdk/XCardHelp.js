// PDKCardHelp.prototype.Config={
//     CardType:PDKCardType,
//     Battle:PDKBattle,
// };