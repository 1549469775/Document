PDKCardType.prototype.Config={
    CardInfo:PDKCardInfo,
  };