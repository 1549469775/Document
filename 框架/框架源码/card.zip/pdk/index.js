function PDKCardInfo(card,convert) {
    BaseCardInfo.apply(this, arguments);
}
inheritPrototype(PDKCardInfo, BaseCardInfo); //继承


function PDKCardType(hand,offsetMagic,magicType){
    BaseCardType.apply(this,arguments);
  }
  inheritPrototype(PDKCardType,BaseCardType);//继承

  function PDKBattle(){
    BaseBattle.apply(this,arguments);
  }
  inheritPrototype(PDKBattle,BaseBattle);//继承

function PDKCardHelp(cards,hands){
    BaseCardHelp.apply(this,arguments);
}
inheritPrototype(PDKCardHelp,BaseCardHelp);//继承

// PDKBattle.prototype.Config={
//     CardType:PDKCardType,
//     CardHelp:PDKCardHelp
// }

// PDKCardHelp.prototype.Config={
//     CardType:PDKCardType,
//     Battle:PDKBattle,
// };

// PDKCardInfo.prototype.COnfig={
//     weight:1,//牌的权重定义
//     cardWeight:[12,13,1,2,3,4,5,6,7,8,9,10,11],//A,2,3,4,5,6,7,8,9,10,J,Q,K
//     convert:1,//牌的转换,
//     //当算法卡组与实际卡组不同时使用
//     convertHand:[
//         1,2,3,4,5,6,7,8,9,10,11,12,13,
//         21,22,23,24,25,26,27,28,29,30,31,32,33,
//         41,42,43,44,45,46,47,48,49,50,51,52,53,
//         61,62,63,64,65,66,67,68,69,70,71,72,73,
//         101,102,
//     ],
//     magic:function(card){
//       return false;
//     },
// }

// PDKCardType.prototype.Config={
//     CardInfo:PDKCardInfo,
//   };

