PDKBattle.prototype.Config={
    CardType:PDKCardType,
    CardHelp:PDKCardHelp
}

