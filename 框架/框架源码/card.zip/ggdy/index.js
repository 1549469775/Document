function GDYCardInfo(card,convert) {
    BaseCardInfo.apply(this, arguments);
}
inheritPrototype(GDYCardInfo, BaseCardInfo); //继承


function GDYCardType(hand,offsetMagic,magicType){
    BaseCardType.apply(this,arguments);
  }
  inheritPrototype(GDYCardType,BaseCardType);//继承

  function GDYBattle(){
    BaseBattle.apply(this,arguments);
  }
  inheritPrototype(GDYBattle,BaseBattle);//继承

function GDYCardHelp(cards,hands){
    BaseCardHelp.apply(this,arguments);
}
inheritPrototype(GDYCardHelp,BaseCardHelp);//继承