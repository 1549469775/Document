GDYCardHelp.prototype.Config = {
    CardType: GDYCardType,
    Battle: GDYBattle,
};

GDYCardHelp.prototype.battle = function (cards, hands) {
    var that = this;

    var lenHand = hands.length; //需要分离出癞子
    var lenCard = cards.length; //可以不用管癞子

    cards = new this.Config.CardType(cards);
    hands = new this.Config.CardType(hands);

    var type = cards.type;

    var cardsWE = cards.device.weight;
    var cardsCO = cards.device.color;
    var cardsNU = cards.device.number;
    var cardsID = cards.device.id;
    var cardsOrigin = cards.device.origin;
    var cardsallNum = cards.count.allNum;
    var cardsmaxNum = cards.count.maxNum;

    var handsMagic = hands.magicCard; //万能牌
    var handsWE = hands.device.weight;
    var handsCO = hands.device.color;
    var handsNU = hands.device.number;
    var handsID = hands.device.id;
    var handsOrigin = hands.device.origin;
    var handsallNum = hands.count.allNum;
    var handsmaxNum = hands.count.maxNum;

    function NUM(number, more) {
        var result = [];
        var weights = that.groupsWeight(hands.cards)
        for (var key in weights) {
            if (more) {
                if (weights.hasOwnProperty(key) && weights[key].length >= number) {
                    result.push(that.deviceOrigin(weights[key]));
                }
            } else {
                if (weights.hasOwnProperty(key) && weights[key].length == number) {
                    result.push(that.deviceOrigin(weights[key]));
                }
            }
        }
        return result;
    }
    // console.log(NUM(1,true));
    // console.log(handsMagic);
    var middle = type.cardId[type.cardWe.indexOf(type.weight)] //关键牌
    // console.log(middle);
    // 3,4,5,6,7,8,9,10,J,Q,K,A,2
    //先找到关键牌，即决定权重的牌
    //然后根据权重的牌进行构建合适的牌型
    //如果牌型符合，则提示，包括癞子
    var beatYou;

    switch (type.type) {
        case 'dan':
            //取单张
            var cardWeight = type.cardWeight; //牌组权重
            var weight = type.weight; //同类型牌组的权重
            for (var i = 0; i < handsWE.length; i++) {
                //同类型压制
                if (handsWE[i] > weight && this.$battle.beat([handsOrigin[i]], cardsOrigin)) {
                    beatYou = [handsOrigin[i]];
                    break;
                }
            }
            break;
        case 'dui':
            //癞子X1-->dui->dan+1
            var two = NUM(2, true);
            var len = two.length;
            for (var i = 0; i < len; i++) {
                var tt = [].concat(two[i]);
                tt.length = 2;
                if (this.$battle.beat(tt, cardsOrigin)) {
                    beatYou = tt;
                    break;
                }
            }
            if (beatYou == undefined && handsMagic.length > 0) {
                //原生没有压制的话，如果有癞子则加入癞子试一下
                //先取出适合权重的牌，然后判断时加入癞子
                var one = NUM(1, true);
                var len = one.length;
                console.log(type); //cardWeight牌型权重，weight同牌型权重
                for (var i = 0; i < len; i++) {
                    var element = one[i][0];
                    if (this.$battle.beat([element, handsMagic[0].origin], cardsOrigin)) {
                        beatYou = [element, handsMagic[0].origin];
                        break;
                    }
                }
            }
            break;
        case 'shun':
            var cardWeight = type.cardWeight; //牌组权重
            var weight = type.weight; //同类型牌组的权重
            var typetimes = type.typetimes; //几顺
            var bigger = this.bigerCardsSHUN(weight, typetimes, 1);

            for (var i = 0; i < bigger.length; i++) {
                var less = this.lessmagicjudge(bigger[i], hands, 1); //缺少几个精
                if (less.less <= handsMagic.length) {
                    var rrr = [].concat(less.result);
                    for (var j = 0; j < less.less; j++) {
                        rrr.push(handsMagic[j].origin);
                    }
                    // debugger
                    if (this.$battle.equalType(rrr, cardsOrigin) && this.$battle.beat(cardsOrigin, rrr, true)) { //,weight+1,type.type
                        beatYou = rrr;
                        break;
                    }
                }
            }
            break;
        case 'duishun':
            var cardWeight = type.cardWeight; //牌组权重
            var weight = type.weight; //同类型牌组的权重
            var typetimes = type.typetimes; //几顺
            //癞子X1-->[we+n,...,we+num+n]随机替换一张
            //癞子X2-->[we+n,...,we+num+n]随机替换2张
            var bigger = this.bigerCardsSHUN(weight, typetimes, 1);
            for (var i = 0; i < bigger.length; i++) {
                var less = this.lessmagicjudge(bigger[i], hands, 2); //缺少几个精
                if (less.less <= handsMagic.length) {
                    var rrr = [].concat(less.result);
                    for (var j = 0; j < less.less; j++) {
                        rrr.push(handsMagic[j].origin);
                    }
                    // debugger
                    if (this.$battle.beat(cardsOrigin, rrr, true)) { //,weight+1,type.type
                        beatYou = rrr;
                        break;
                    }
                }
            }
            break;
    }
    if (beatYou) {
        this.beatYou = beatYou;
        return;
    }
    //判断炸弹，有炸就炸
    var zha = NUM(3, true);
    var len = zha.length;
    for (var i = 0; i < len; i++) {
        if (this.$battle.beat(zha[i], cardsOrigin)) {
            beatYou = zha[i];
            break
        }
    }
    //两个癞子
    if (beatYou == undefined && handsMagic.length == 1) {
        var zha = NUM(2, true);
        var len = zha.length;
        for (var i = 0; i < len; i++) {
            var ggg = [].concat(zha[i])
            ggg.push(handsMagic[0].origin)
            if (this.$battle.beat(ggg, cardsOrigin)) {
                beatYou = ggg;
                break
            }
        }
    } else if (beatYou == undefined && handsMagic.length == 2) {
        var zha = NUM(1, true);
        zha.sort(function (a, b) {
            return a.length - b.length;
        })
        var len = zha.length;
        for (var i = 0; i < len; i++) {
            var ggg = [].concat(zha[i])
            ggg.push(handsMagic[0].origin)
            ggg.push(handsMagic[1].origin)
            if (this.$battle.beat(ggg, cardsOrigin)) {
                beatYou = ggg;
                break
            }
        }
    }
    if (beatYou) {
        this.beatYou = beatYou;
        return;
    }
    if(handsMagic.length==2){
        if (this.$battle.beat([handsMagic[0].origin,handsMagic[1].origin], cardsOrigin)) {
            beatYou = [handsMagic[0].origin,handsMagic[1].origin];
        }
    }
    if (beatYou) {
        this.beatYou = beatYou;
        return;
    }
}