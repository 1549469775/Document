GDYBattle.prototype.Config={
    CardType:GDYCardType,
    CardHelp:GDYCardHelp
}

GDYBattle.prototype.tip = function (cards, hands) {
    var result=new this.Config.CardHelp(cards,hands);
    return result.beatYou;
};

GDYBattle.prototype.beat = function (prevArr1, nextArr2,change) {
    if (change) {
        //右边大于左边,左边确定
        nextArr = new this.Config.CardType(prevArr1);
        var nextType = nextArr.type;
        if (nextType.type !== 'error') {
            prevArr = new this.Config.CardType(nextArr2,nextType.weight+1,nextType.type);
            var prevType = prevArr.type;
        }
    }else{
        //左边大于右边,左边确定
        prevArr = new this.Config.CardType(prevArr1);
        var prevType = prevArr.type;
        if (prevType.type !== 'error') {
            nextArr = new this.Config.CardType(nextArr2,prevType.weight-1,prevType.type);
            var nextType = nextArr.type;
        }
    }
    if (prevType && nextType && prevType !== 'error' && nextType !== 'error') {
        if (prevType.cardWeight == nextType.cardWeight) {
            if (prevType.type == nextType.type) {
                if (prevType.cardNum.length == nextType.cardNum.length) {
                    if (prevType.weight > nextType.weight && prevType.weight == 13) {
                        return true;
                    }
                    if (prevType.weight > nextType.weight && (prevType.weight - nextType.weight) == 1) {
                        return true;
                    }
                }
            }
        } else if (prevType.cardWeight > nextType.cardWeight) {
            return true;
        }
    }
    return false;
};
