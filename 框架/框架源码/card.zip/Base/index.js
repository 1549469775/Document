function inheritObject(o) {
    function F() {}
    F.prototype = o;
    return new F();
}

/* 寄生组合式继承 */
function inheritPrototype(subType, superType) {
    var prototype = inheritObject(superType.prototype);
    prototype.constructor = subType;
    subType.prototype = prototype;
}

