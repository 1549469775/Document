

function BaseCardInfo(card,convert) {
    this.id = -1; //物理纸牌
    this.num = -1 // 物理大小
    this.color = -1; //物理花色
    this.weight = -1; //算法权重
    card=convert?this.convertIn(card):card;
    this.id = card;
    this.origin=convert?this.convertOut(card):card;
    this.color = parseInt(String(this.id)[0]); //物理大小
    this.num = parseInt(String(this.id).slice(1)); //物理花色
    var weight=this.Config.weight==1?this.Config.cardWeight:[12,13,1,2,3,4,5,6,7,8,9,10,11];
    this.weight = weight[this.num-1];
    this.img=["♣梅花","♦方片","♥红桃","♠黑桃","鬼"][this.color-1]+this.num;
    this.magic=false;
    //花色>4为癞子
    if (this.Config.magic(this)) {
      this.magic=true;
    }
  }
  
  BaseCardInfo.prototype.deviceNum=function(){
    //分离单个纸牌
    return this.num;
  }

  BaseCardInfo.prototype.convertOut=function(one){
      if(!this.Config.convert) return one;
      var result;
      var _from=this.Config.convertHand;
      var _to=[
          11,12,13,14,15,16,17,18,19,110,111,112,113,
          21,22,23,24,25,26,27,28,29,210,211,212,213,
          31,32,33,34,35,36,37,38,39,310,311,312,313,
          41,42,43,44,45,46,47,48,49,410,411,412,413,
          51,52,
      ];
      var index=_to.indexOf(one);
      if (index==-1){
        throw "牌型错误"
      }
      result=_from[index];
      return result;
  };
  BaseCardInfo.prototype.convertIn=function(one){
      if(!this.Config.convert) return one;
      var result;
      var _from=this.Config.convertHand;
      var _to=[
          11,12,13,14,15,16,17,18,19,110,111,112,113,
          21,22,23,24,25,26,27,28,29,210,211,212,213,
          31,32,33,34,35,36,37,38,39,310,311,312,313,
          41,42,43,44,45,46,47,48,49,410,411,412,413,
          51,52,
      ];
      var index=_from.indexOf(one);
      if (index==-1){
        throw "牌型错误"
      }
      result=_to[index];
      return result;
  };


