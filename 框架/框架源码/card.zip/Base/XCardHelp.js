    
    //作用：纸牌+癞子可以组成的最大的牌
    function BaseCardHelp(cards,hands) {
        this.build(BaseCardTool.prototype);
        this.use('battle',new this.Config.Battle());//这个需要修改
        this.battle(cards,hands);
    }

    BaseCardHelp.prototype.use = function (name, object) {
        BaseCardHelp.prototype['$' + name] = object;
    }

    BaseCardHelp.prototype.build = function (object) {
        for (var key in object) {
            // if (object.hasOwnProperty(key)) {
                var element = object[key];
                BaseCardHelp.prototype[key] = element;
            // }
        }
    }
    
    /**
     * 当前权重
     * 几顺
     * 个数
     */
    BaseCardHelp.prototype.bigerCardsSHUN=function(weight,typetimes,offset){
        var maxweight=12-typetimes+1;//连顺的最高全级
        if (this.Config.MaxWeight) {
            var maxweight=this.Config.MaxWeight-typetimes+1;//QKA
        }
        var ccc=[];
        for (var i = weight; i < maxweight; i++) {
            var wes=[];
            for (var j = 0; j < typetimes; j++) {
                wes[j]=weight+i-weight+1+j;
            }
            if (offset==undefined) {
                ccc.push(wes);
            }
            if (offset&&(weight+offset)>=wes[0]) {
                ccc.push(wes);
            }
        }
        
        return ccc;
    }

    BaseCardHelp.prototype.lessmagicjudge=function(targetArr,hands,mutis){
        var less=0;
        var result=[];
        var that=this;
        var insertNUM=function(target,num){
            var len=0;
            if (num==0) {
                return;
            }
            for (var i = 0; i < hands.cards.length; i++) {
                if (target==hands.device.weight[i]) {
                    len++;
                    result.push(hands.device.origin[i]);
                    if (len==num) {
                        break;
                    }
                }
            }
        };
        var insertMain=function(target,num){
            var less=0;
            for (var j = 0; j < num; j++) {
                if (that.checkNUM(target,hands.device.weight)==j) {
                    less+=num-j;
                    insertNUM(target,num);
                }
            }
            if (that.checkNUM(target,hands.device.weight)>=num) {
                insertNUM(target,num);
            }
            return less;
        }
        // debugger
        for (var j = 0; j < targetArr.length; j++) {
            
            less+=insertMain(targetArr[j],mutis);
        }
        return {result:result,less:less};
    }

    BaseCardHelp.prototype.battle=function(cards,hands){
        var that=this;

        cards = new this.Config.CardType(cards);
        hands = new this.Config.CardType(hands);

        var lenHand = hands.length; //需要分离出癞子
        var lenCard = cards.length; //可以不用管癞子
        var type = cards.type;
        var cardsWE = cards.device.weight;
        var cardsCO = cards.device.color;
        var cardsNU = cards.device.number;
        var cardsID = cards.device.id;
        var cardsOrigin = cards.device.origin;
        var cardsallNum = cards.count.allNum;
        var cardsmaxNum = cards.count.maxNum;

        var handsMagic = hands.magicCard; //万能牌
        var handsWE = hands.device.weight;
        var handsCO = hands.device.color;
        var handsNU = hands.device.number;
        var handsID = hands.device.id;
        var handsOrigin = hands.device.origin;
        var handsallNum = hands.count.allNum;
        var handsmaxNum = hands.count.maxNum;

        function NUM(number, more) {
            var result = [];
            var weights = that.groupsWeight(hands.cards)
            for (var key in weights) {
                if (more) {
                    if (weights.hasOwnProperty(key) && weights[key].length >= number) {
                        result.push(that.deviceOrigin(weights[key]));
                    }
                } else {
                    if (weights.hasOwnProperty(key) && weights[key].length == number) {
                        result.push(that.deviceOrigin(weights[key]));
                    }
                }
            }
            return result;
        }

        var beatYou;
        
        switch (type.type) {
            case 'dan':
                //取单张
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                for (var i = 0; i < handsWE.length; i++) {
                    //同类型压制
                    if (handsWE[i]>weight&&this.$battle.beat([handsOrigin[i]],cardsOrigin)) {
                        beatYou=[handsOrigin[i]];
                        break;
                    }
                }
                break;
            case 'dui':
                //癞子X1-->dui->dan+1
                var two=NUM(2,true);
                var len=two.length;
                for (var i = 0; i < len; i++) {
                    var tt=[].concat(two[i]);
                    tt.length=2;
                    if (this.$battle.beat(tt,cardsOrigin)) {
                        beatYou=tt;
                        break;
                    }
                }
                break;
            case 'san':
                //癞子X1-->dui->dan+1
                var two=NUM(3,true);
                var len=two.length;
                for (var i = 0; i < len; i++) {
                    var tt=[].concat(two[i]);
                    tt.length=3;
                    if (this.$battle.beat(tt,cardsOrigin)) {
                        beatYou=tt;
                        break;
                    }
                }
                break;
            case 'shun':
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                var typetimes = type.typetimes; //几顺
                var bigger = this.bigerCardsSHUN(weight,typetimes);
                
                for (var i = 0; i < bigger.length; i++) {
                    var less=this.lessmagicjudge(bigger[i],hands,1);//缺少几个精
                    if (less.less<=handsMagic.length) {
                        var rrr=[].concat(less.result);
                        for (var j = 0; j < less.less; j++) {
                            rrr.push(handsMagic[j].origin);
                        }
                        // debugger
                        if (this.$battle.equalType(rrr,cardsOrigin)&&this.$battle.beat(cardsOrigin,rrr,true)) {//,weight+1,type.type
                            beatYou=rrr;
                            break;
                        }
                    }
                }
                break;
            case 'duishun':
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                var typetimes = type.typetimes; //几顺
                //癞子X1-->[we+n,...,we+num+n]随机替换一张
                //癞子X2-->[we+n,...,we+num+n]随机替换2张
                var bigger = this.bigerCardsSHUN(weight,typetimes);
                for (var i = 0; i < bigger.length; i++) {
                    var less=this.lessmagicjudge(bigger[i],hands,2);//缺少几个精
                    if (less.less<=handsMagic.length) {
                        var rrr=[].concat(less.result);
                        for (var j = 0; j < less.less; j++) {
                            rrr.push(handsMagic[j].origin);
                        }
                        // debugger
                        if (this.$battle.beat(cardsOrigin,rrr,true)) {//,weight+1,type.type
                            beatYou=rrr;
                            break;
                        }
                    }
                }
                break;
            case 'sanshun':
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                var typetimes = type.typetimes; //几顺
                //癞子X1-->[we+n,...,we+num+n]随机替换一张
                //癞子X2-->[we+n,...,we+num+n]随机替换2张
                var bigger = this.bigerCardsSHUN(weight,typetimes);
                for (var i = 0; i < bigger.length; i++) {
                    var less=this.lessmagicjudge(bigger[i],hands,3);//缺少几个精
                    if (less.less<=handsMagic.length) {
                        var rrr=[].concat(less.result);
                        for (var j = 0; j < less.less; j++) {
                            rrr.push(handsMagic[j].origin);
                        }
                        // debugger
                        if (this.$battle.beat(cardsOrigin,rrr,true)) {//,weight+1,type.type
                            beatYou=rrr;
                            break;
                        }
                    }
                }
                break;
        }
        if (beatYou) {
            this.beatYou=beatYou;
            return;
        }
        //判断炸弹，有炸就炸
        var zha=NUM(4,true);
        var len=zha.length;
        for (var i = 0; i < len; i++) {
            if (this.$battle.beat(zha[i],cardsOrigin)) {
                beatYou=zha[i];
            }
        }
        if (beatYou) {
            this.beatYou=beatYou;
            return;
        }
        //判断天王炸
        
    }