

  BaseCardType.prototype.use=function(name,object){
    BaseCardType.prototype['$'+name]=object;
  }

  BaseCardType.prototype.build=function(object){
    for (var key in object) {
      if (object.hasOwnProperty(key)) {
        var element = object[key];
        BaseCardType.prototype[key]=element;
      }
    }
  }

  //牌型构造
  function BaseCardType(hand,offsetMagic,magicType) {
    this.build(BaseCardTool.prototype);
    var cards=[]; 
    try {
      for (var i = 0; i < hand.length; i++) {
        // hand[i]=this.convertIn(hand[i]);
        var element = hand[i];
        cards[i]=new this.Config.CardInfo(element,true);
      }
    } catch (e) {
      debugger
    }
    this.offsetMagic=offsetMagic||0;
    this.magicType=magicType||0;
    this.cards=[].concat(cards);
    this.weightSort(this.cards);//权重排序
    this.device={
        weight:this.deviceWeight(this.cards),
        color:this.deviceColor(this.cards),
        number:this.deviceNum(this.cards),
        id:this.deviceId(this.cards),
        origin:this.deviceOrigin(this.cards),
    }
   
    this.count={};
    this.count.allNum=this.allNumber(this.device.weight)//牌数
    this.count.maxNum=this.maxNumber(this.count.allNum)//牌数
    this.check();
    //dan,shun%d,dui,duishun%d,san,sanshun%d,zha
  }
  
  BaseCardType.prototype.createType=function(type,typetimes,cardWeight,weight,cardNum,cardColor,cardId,cardWe){
    return {
      type:type,
      typetimes:typetimes,
      cardWeight:cardWeight,
      weight:weight,
      cardNum:cardNum,
      cardColor:cardColor,
      cardId:cardId,
      cardWe:cardWe,
    }
  }
  
  //检测牌型
  BaseCardType.prototype.checkTong=function(cards){
    cards=[].concat(cards);
    magic_cards=[].concat(this.magicCard);
    var cardsWE=this.deviceWeight(cards);
    // var cardsCO=this.deviceColor(cards);
    // var cardsNU=this.deviceNum(cards);
    // var cardsID=this.deviceId(cards);
    // var cardsOrigin=this.deviceOrigin(cards);
    var allNum=this.allNumber(cardsWE);//牌数
    var maxNum=this.maxNumber(allNum);//多数;
    
    var result;
    if (cards.length==0) {
      return;
    }
    var number=allNum[0].num;
    switch (number) {
      case 1:
        if (allNum.length>=5
          &&allNum.length==maxNum.length
          &&this.checkSHUN(cardsWE)
          && allNum[ allNum.length-1].val<13) {
          result=this.createType(
            "shun",allNum.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight
            );
        }else if ( allNum.length==1&& allNum.length== maxNum.length) {
          result=this.createType("dan",1,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
        }
        break;
      case 2:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==2) {
            result=this.createType("dui",1,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        if ( allNum.length>=3
          && allNum[ allNum.length-1].num==2
          && allNum.length== maxNum.length) {
            var card= cardsWE.filter((v,i,s)=>{
              return  cardsWE.indexOf(v)==i;
            });
            if (this.checkSHUN(card)&&card[card.length-1]<13) {
              result=this.createType("duishun",card.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
            }
        }
        break;
      case 3:
        if ( allNum.length>1
          && allNum[ allNum.length-1].num==3) {
            var card= cardsWE.filter((v,i,s)=>{
              return  cardsWE.indexOf(v)==i;
            });
            if (this.checkSHUN(card)&&card[card.length-1]<13) {
              // console.log("三顺",cardsWE);
              result=this.createType("sanshun",card.length,1,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
            }
        }else if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==3) {
            // console.log("三张", cardsWE);
            result=this.createType("san",1,2,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
      case 4:
        if ( allNum.length==1&& maxNum.length==1) {
          if ( maxNum[0].num==4) {
            result=this.createType("zha",1,3,cardsWE[0],this.device.number,this.device.color,this.device.id,this.device.weight);
          }
        }
        break;
    }
    if (result) {
      return result;
    }
  };
  
  BaseCardType.prototype.checkDai=function(cards){
    //判断3+1,3+(2),3+3+(4),3+3+3+(6)
    //判断4+1,4+(2)
    cards=[].concat(cards);
    magic_cards=[].concat(this.magicCard);
    var cardsWE=this.deviceWeight(cards);
    // var cardsCO=this.deviceColor(cards);
    // var cardsNU=this.deviceNum(cards);
    // var cardsID=this.deviceId(cards);
    // var cardsOrigin=this.deviceOrigin(cards);
    var allNum=this.allNumber(cardsWE);//牌数
    // var maxNum=this.maxNumber(allNum);//多数;
    var result;
    if (result) {
      return result;
    }
  }
  
  BaseCardType.prototype.checkGod=function(cards){
    cards=[].concat(cards);
    var cardsWE=this.deviceWeight(cards);
    var cardsCO=this.deviceColor(cards);
    var result;
    if (cardsCO.length==2&&cardsCO[0]>4&&cardsCO[1]>4) {
      result=this.createType("god",100,cardsWE[0],cardsWE);
    }
    if (result) {
      return result;
    }
  }
  
  
  BaseCardType.prototype.checkMagic=function(){
    var magicType;
    return magicType;
  }
  
  BaseCardType.prototype.checkAll=function(cards){
    this.weightSort(cards);
    var type=this.checkTong(cards);
    (!type)&&(type=this.checkGod(cards));
    return type=type||'error';
  }
  
  BaseCardType.prototype.check=function(){
    this.magicCard=this.deviceMagic(this.cards);//分离癞子
    var type=this.checkAll(this.cards);//判断牌型
    var magicType=this.checkMagic();//检测癞子能组的最大类型
    this.type=type||'error';
    // this.magicType=magicType||'error';
    (magicType)&&(this.type=magicType);//癞子类型覆盖
    this.type.__proto__=null;
  }
