
BaseBattle.prototype.Config = {
    CardType: BaseCardType,//内部挂载的对象
    CardHelp: BaseCardHelp,//内部挂载的对象
}

BaseCardHelp.prototype.Config = {
    CardType: BaseCardType,//内部挂载的对象
    Battle: BaseBattle,//内部挂载的对象
    MaxWeight: 12,//顺子最高等级,3-A
};

BaseCardType.prototype.Config = {
    CardInfo: BaseCardInfo,//内部挂载的对象
    checkDIY:function(){//TODO子游戏牌型检测
        return false;
    },
};

BaseCardInfo.prototype.Config = {
    weight: 1, //牌的权重定义
    cardWeight: [12, 13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], //A,2,3,4,5,6,7,8,9,10,J,Q,K
    convert: 1, //牌的转换,
    //当算法卡组与实际卡组不同时使用
    convertHand: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
        21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
        61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73,
        101, 102,
    ],
    magic: function (card) {
        return false;
    },
};

console.log("%c 算法 v1.0 %c by谢亚昕 | www.xieyaxin.top","color:#444;background:#eee;padding:5px 0;","color:#eee;background:#444;padding:5px 3px;");