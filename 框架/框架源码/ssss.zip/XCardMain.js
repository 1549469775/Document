console.time("god");
console.log(Battle.gdytip([3,4,5],[6,6,47,67,10,25,27,28,101,102]));
console.log(Battle.gdytip([4,4,5,5,6,6],[5,5,6,6,101,102]));
console.log(Battle.gdybeat([7,7,8,8,6,6],[5,5,6,6,101,102]));
console.log(Battle.check([1]));
console.timeEnd("god");
// 文件加载顺序
// XCardConfig.js
// XCardTool.js
// XCardInfo.js
// XCardType.js
// XCardBattle.js
// XCardHelp.js
// XCardMain.js //用于测试，可以不加