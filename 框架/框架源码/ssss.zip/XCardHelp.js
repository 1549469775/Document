    CardHelp.prototype.use = function (name, object) {
        CardHelp.prototype['$' + name] = object;
    }

    CardHelp.prototype.build = function (object) {
        for (const key in object) {
            if (object.hasOwnProperty(key)) {
                const element = object[key];
                CardHelp.prototype[key] = element;
            }
        }
    }

    //作用：纸牌+癞子可以组成的最大的牌
    function CardHelp(cards, hands) {
        this.build(CardTool.prototype);
        this.build(Battle);
        var that=this;

        var lenHand = hands.length; //需要分离出癞子
        var lenCard = cards.length; //可以不用管癞子

        cards = new CardType(cards);
        hands = new CardType(hands);

        var type = cards.type;
        
        var cardsWE = cards.device.weight;
        var cardsCO = cards.device.color;
        var cardsNU = cards.device.number;
        var cardsID = cards.device.id;
        var cardsOrigin = cards.device.origin;
        var cardsallNum = cards.count.allNum;
        var cardsmaxNum = cards.count.maxNum;

        var handsMagic = hands.magicCard; //万能牌
        var handsWE = hands.device.weight;
        var handsCO = hands.device.color;
        var handsNU = hands.device.number;
        var handsID = hands.device.id;
        var handsOrigin = hands.device.origin;
        var handsallNum = hands.count.allNum;
        var handsmaxNum = hands.count.maxNum;

        function NUM(number, more) {
            var result = [];
            var weights = that.groupsWeight(hands.cards)
            for (const key in weights) {
                if (more) {
                    if (weights.hasOwnProperty(key) && weights[key].length >= number) {
                        result.push(that.deviceOrigin(weights[key]));
                    }
                } else {
                    if (weights.hasOwnProperty(key) && weights[key].length == number) {
                        result.push(that.deviceOrigin(weights[key]));
                    }
                }
            }
            return result;
        }
        // console.log(NUM(1,true));
        // console.log(handsMagic);
        var middle=type.cardId[type.cardWe.indexOf(type.weight)]//关键牌
        // console.log(middle);
        // 3,4,5,6,7,8,9,10,J,Q,K,A,2
        //先找到关键牌，即决定权重的牌
        //然后根据权重的牌进行构建合适的牌型
        //如果牌型符合，则提示，包括癞子
        var beatYou;
        
        switch (type.type) {
            case 'dan':
                //取单张
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                for (let i = 0; i < handsWE.length; i++) {
                    //同类型压制
                    if (handsWE[i]>weight&&this.beat([handsOrigin[i]],cardsOrigin)) {
                        beatYou=[handsOrigin[i]];
                        break;
                    }
                }
                break;
            case 'dui':
                //癞子X1-->dui->dan+1
                var two=NUM(2,true);
                var len=two.length;
                for (let i = 0; i < len; i++) {
                    var tt=[].concat(two[i]);
                    tt.length=2;
                    if (this.beat(tt,cardsOrigin)) {
                        beatYou=tt;
                        break;
                    }
                }
                break;
            case 'shun':
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                var typetimes = type.typetimes; //几顺
                var bigger = this.bigerCardsSHUN(weight,typetimes,1);
                for (let i = 0; i < bigger.length; i++) {
                    var less=this.lessmagicjudge(bigger[i],hands,1);//缺少几个精
                    if (less.less<=handsMagic.length) {
                        var rrr=[].concat(less.result);
                        for (let j = 0; j < less.less; j++) {
                            rrr.push(handsMagic[j].origin);
                        }
                        // debugger
                        if (this.equalType(rrr,cardsOrigin)&&this.beat(rrr,cardsOrigin)) {//,weight+1,type.type
                            beatYou=rrr;
                        }
                    }
                }
                break;
            case 'duishun':
                var cardWeight = type.cardWeight; //牌组权重
                var weight = type.weight; //同类型牌组的权重
                var typetimes = type.typetimes; //几顺
                //癞子X1-->[we+n,...,we+num+n]随机替换一张
                //癞子X2-->[we+n,...,we+num+n]随机替换2张
                var bigger = this.bigerCardsSHUN(weight,typetimes,1);
                for (let i = 0; i < bigger.length; i++) {
                    var less=this.lessmagicjudge(bigger[i],hands,2);//缺少几个精
                    if (less.less<=handsMagic.length) {
                        var rrr=[].concat(less.result);
                        for (let j = 0; j < less.less; j++) {
                            rrr.push(handsMagic[j].origin);
                        }
                        // debugger
                        if (this.beat(rrr,cardsOrigin)) {//,weight+1,type.type
                            beatYou=rrr;
                        }
                    }
                }
                break;
        }
        if (beatYou) {
            this.beatYou=beatYou;
            return;
        }
        //判断炸弹，有炸就炸
        var zha=NUM(4,true);
        var len=zha.length;
        for (let i = 0; i < len; i++) {
            if (this.beat(zha[i],cardsOrigin)) {
                beatYou=zha[i];
            }
        }
        if (beatYou) {
            this.beatYou=beatYou;
        }
    }
    /**
     * 当前权重
     * 几顺
     * 个数
     */
    CardHelp.prototype.bigerCardsSHUN=function(weight,typetimes,offset){
        var maxweight=12-typetimes+1;//连顺的最高全级
        if (Config.weight) {
            var maxweight=12-typetimes+1;//QKA
        }
        var ccc=[];
        for (let i = weight; i < maxweight; i++) {
            var wes=[];
            for (let j = 0; j < typetimes; j++) {
                wes[j]=weight+i-weight+1+j;
            }
            if (offset==undefined) {
                ccc.push(wes);
            }
            if (offset&&(weight+offset)>=wes[0]) {
                ccc.push(wes);
            }
        }
        
        return ccc;
    }

    CardHelp.prototype.lessmagicjudge=function(targetArr,hands,mutis){
        var less=0;
        var result=[];
        var that=this;
        var insertNUM=function(target,num){
            var len=0;
            if (num==0) {
                return;
            }
            for (let i = 0; i < hands.cards.length; i++) {
                if (target==hands.device.weight[i]) {
                    len++;
                    result.push(hands.device.origin[i]);
                    if (len==num) {
                        break;
                    }
                }
            }
        };
        var insertMain=function(target,num){
            var less=0;
            for (let j = 0; j < num; j++) {
                if (that.checkNUM(target,hands.device.weight)==j) {
                    less+=num-j;
                    insertNUM(target,num);
                }
            }
            if (that.checkNUM(target,hands.device.weight)>=num) {
                insertNUM(target,num);
            }
            return less;
        }
        // debugger
        for (let j = 0; j < targetArr.length; j++) {
            
            less+=insertMain(targetArr[j],mutis);
        }
        return {result:result,less:less};
    }